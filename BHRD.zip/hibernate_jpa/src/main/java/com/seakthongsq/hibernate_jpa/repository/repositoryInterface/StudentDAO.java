package com.seakthongsq.hibernate_jpa.repository.repositoryInterface;

import com.seakthongsq.hibernate_jpa.repository.model.Student;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository
public interface StudentDAO {
    @Insert("INSERT INTO tbStudents(name, gender) VALUES(#{name},#{gender})")
    public boolean save(Student student);

    @Delete("DELETE FROM tbStudents WHERE id=#{id}")
    public boolean delete(int id);

    @Update("Update tbStudents SET name=#{name}, gender=#{gender} WHERE id=#{id}")
    public boolean update(Student student);

    @Select("SELECT id, name, gender FROM tbStudents ORDER BY id ASC")
    @Results({
            @Result(property = "id",column = "id"),
            @Result(property = "name",column = "name"),
            @Result(property = "gender",column = "gender")
    })
    public ArrayList<Student> findAll();
}
