INSERT INTO tblcategories VALUES(0,'Default', 1);
INSERT INTO tblcategories (name, status) VALUES('Spring', 1);
INSERT INTO tblcategories (name, status) VALUES('HTML', 1);
INSERT INTO tblcategories (name, status) VALUES('JS', 1);





-- INSERT INTO tblarticles (title, author, description, thumbnail, status, category_id) VALUES ('Love Is Singular', 'Tena', 'd', 't', 1, 1);
INSERT INTO tblarticles (title, author, description, thumbnail, status, category_id) VALUES ('Spring', 'S', 'ssssssssss', 'thumbnail/default.png', 1, 1);
INSERT INTO tblarticles (title, author, description, thumbnail, status, category_id) VALUES ('Spring', 'S', 'ssssssssss', 'thumbnail/default.png', 1, 1);
INSERT INTO tblarticles (title, author, description, thumbnail, status, category_id) VALUES ('Spring', 'S', 'ssssssssss', 'thumbnail/default.png', 1, 1);
INSERT INTO tblarticles (title, author, description, thumbnail, status, category_id) VALUES ('HTML', 'H', 'hhhhhhhhhh', 'thumbnail/default.png', 1, 2);
INSERT INTO tblarticles (title, author, description, thumbnail, status, category_id) VALUES ('HTML', 'H', 'hhhhhhhhhh', 'thumbnail/default.png', 1, 2);
INSERT INTO tblarticles (title, author, description, thumbnail, status, category_id) VALUES ('HTML', 'H', 'hhhhhhhhhh', 'thumbnail/default.png', 1, 2);
INSERT INTO tblarticles (title, author, description, thumbnail, status, category_id) VALUES ('HTML', 'H', 'hhhhhhhhhh', 'thumbnail/default.png', 1, 2);
INSERT INTO tblarticles (title, author, description, thumbnail, status, category_id) VALUES ('JS', 'J', 'jjjjjjjjjj', 'thumbnail/default.png', 1, 3);
INSERT INTO tblarticles (title, author, description, thumbnail, status, category_id) VALUES ('JS', 'J', 'jjjjjjjjjj', 'thumbnail/default.png', 1, 3);
INSERT INTO tblarticles (title, author, description, thumbnail, status, category_id) VALUES ('JS', 'J', 'jjjjjjjjjj', 'thumbnail/default.png', 1, 3);


-- INSERT INTO tblarticles (title, author, description, thumbnail, status, category_id) VALUES ('Love Is Singular', 'Tena', 'd', 't', 1, 1);
-- INSERT INTO tblarticles (title, author, description, thumbnail, status, category_id) VALUES ('You Are My Love', 'Love', 'd', 't', 1, 1);
-- INSERT INTO tblarticles (title, author, description, thumbnail, status, category_id) VALUES ('Why Do This', 'Kid', 'd', 't', 1, 3);
-- INSERT INTO tblarticles (title, author, description, thumbnail, status, category_id) VALUES ('Sorry My Baby', 'Young', 'd', 't', 1, 4);
-- INSERT INTO tblarticles (title, author, description, thumbnail, status, category_id) VALUES ('Love Rain', 'Nop', 'd', 't', 1, 1);
-- INSERT INTO tblarticles (title, author, description, thumbnail, status, category_id) VALUES ('Sweet for Whom', 'Nop', 'd', 't', 1, 2);
-- INSERT INTO tblarticles (title, author, description, thumbnail, status, category_id) VALUES ('Love You For 365 Days', 'Chhorn', 'd', 't', 1, 1);
-- INSERT INTO tblarticles (title, author, description, thumbnail, status, category_id) VALUES ('Love Because of You', 'Kid', 'd', 't', 1, 1);
-- INSERT INTO tblarticles (title, author, description, thumbnail, status, category_id) VALUES ('Who Wanna Know', 'Nop', 'd', 't', 1, 3);
-- INSERT INTO tblarticles (title, author, description, thumbnail, status, category_id) VALUES ('Miss A Love B', 'Chhorn', 'd', 't', 1, 1);