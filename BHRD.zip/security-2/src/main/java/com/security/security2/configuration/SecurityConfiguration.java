package com.security.security2.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.stereotype.Component;

@Configuration
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {
    @Autowired
    AccessDeniedHandler accessDeniedHandler;
    @Autowired
    CustomAuthenticationSuccessHandler customAuthenticationSuccessHandler;
    @Autowired
    private CustomAuthenticationEntryPoint customAuthenticationEntryPoint;

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.formLogin().loginPage("/login").usernameParameter("username")
                .successHandler(customAuthenticationSuccessHandler);

        http.exceptionHandling().authenticationEntryPoint(customAuthenticationEntryPoint);

//        http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.NEVER);

        http.logout().logoutRequestMatcher( new AntPathRequestMatcher("/logout"));

        http.exceptionHandling().accessDeniedHandler(accessDeniedHandler);

        http.authorizeRequests().antMatchers("/admin/**").hasRole("ADMIN")
                                .antMatchers("/editor/**").hasAnyRole("EDITOR")
                                .antMatchers("/user/**").hasAnyRole("USER","EDITOR");
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.inMemoryAuthentication().withUser("admin").password("{noop}admin").roles("ADMIN")
                                .and().withUser("editor").password("{noop}editor").roles("EDITOR")
                                .and().withUser("user").password("{noop}user").roles("USER");
    }
}
