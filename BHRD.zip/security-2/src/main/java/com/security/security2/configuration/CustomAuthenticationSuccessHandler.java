package com.security.security2.configuration;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@Component
public class CustomAuthenticationSuccessHandler implements AuthenticationSuccessHandler {
    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
        HttpSession session = request.getSession();
        session.setMaxInactiveInterval(60);//Minute
        System.out.println("Login Success");

        System.out.println(authentication.getAuthorities());
        System.out.println(request.getSession().getAttribute("REDIRECT_SUCCESS_URI"));
        String redirection = (String) request.getSession().getAttribute("REDIRECT_SUCCESS_URI");

        for(GrantedAuthority auth : authentication.getAuthorities()){
            System.out.println(auth.getAuthority());
            if(auth.getAuthority().equals("ROLE_USER"))
                response.sendRedirect(redirection);
            else if(auth.getAuthority().equals("ROLE_EDITOR"))
                response.sendRedirect(redirection);
            else if(auth.getAuthority().equals("ROLE_ADMIN"))
                response.sendRedirect(redirection);
            else
                response.sendRedirect("/");

        }
    }

}
