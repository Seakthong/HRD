package com.security.security2.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {
    @GetMapping("/")
    public String index(){return "z-user/index";}

    @GetMapping("/user")
    public String userIndex(){return "user/index";}

    @GetMapping("/user/profile")
    public String getProfile(){return "user/profile";}

    @GetMapping("/editor")
    public String editorIndex(){return "editor/index";}

    @GetMapping("/admin")
    public String adminIndex(){return "admin/index";}


}
