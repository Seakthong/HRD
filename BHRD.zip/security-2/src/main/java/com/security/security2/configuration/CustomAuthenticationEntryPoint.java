package com.security.security2.configuration;

import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component
public class CustomAuthenticationEntryPoint implements AuthenticationEntryPoint {
    //Work when no login to any users
    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException) throws IOException, ServletException {
        System.out.println("Attemp : " + request.getRequestURL());
        //URI:paths or URL: full
        request.getSession().setAttribute("REDIRECT_SUCCESS_URI",request.getRequestURI());
        response.sendRedirect("/login");
    }
}
