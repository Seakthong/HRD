package com.security.security2.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ErrorPageController {
    @GetMapping("/access-denies-handler")
    public String accessDeniesHandler(){
    return "access-denies/error-403";
    }
}
