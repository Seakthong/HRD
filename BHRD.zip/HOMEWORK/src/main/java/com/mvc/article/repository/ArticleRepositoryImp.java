package com.mvc.article.repository;

import com.mvc.article.repository.articleRepository.ArticleRepository;
import com.mvc.article.repository.model.Article;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class ArticleRepositoryImp implements ArticleRepository {
    List<Article> articleList = new ArrayList<>();

    @Override
    public List<Article> ViewAll() {
        return articleList;
    }

    @Override
    public boolean Insert(Article article) {
        articleList.add(article);
        return true;
    }

    @Override
    public boolean Update(int id, Article article) {
        Article obj;
        if(articleList.size() == -1) return  false;
        else{
            for (int i = 0; i < articleList.size(); i++) {
                obj = articleList.get(i);
                if (obj.getId() == article.getId()) {
                    obj.setAuthor(article.getAuthor());
                    obj.setDescription(article.getDescription());
                    obj.setTitle(article.getTitle());
                    obj.setThumbnail(article.getThumbnail());
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean Delete(int id) {
        if(articleList.size() == -1) return false;
        else
            for (int i = 0; i < articleList.size(); i++) {
                if (articleList.get(i).getId() == id) {
                    articleList.remove(i);
                    return true;
                }
            }
            return false;
    }

    @Override
    public Article ViewOneRecord(int id) {
        if(articleList.size()==-1) return null;
        else
            for(int i=0; i< articleList.size(); i++){
                if(articleList.get(i).getId() == id){
                    return articleList.get(i);
                }
            }

        return null;
    }

    @Override
    public int listSize() {
        return articleList.size();
    }

    @Override
    public int lastID() {
        int size = articleList.size();
        if(size == 0) return 0;
        Article me = articleList.get(size-1);
            return me.getId();
    }

    @Override
    public List<Article> ViewPagination(int limit, int page) {
        if(page <=0) page = 1;
        List<Article> newList;
        int size = articleList.size();
        int totalPage = (size%limit != 0 ?size / limit+1 : size/limit);
        if(page > totalPage) page = totalPage;
        int start = page * limit - limit;
        int end = (page == totalPage)?(start + (size%limit==0?limit:size%limit)):page * limit;
        newList = articleList.subList(start, end);
        return newList;
    }
}
