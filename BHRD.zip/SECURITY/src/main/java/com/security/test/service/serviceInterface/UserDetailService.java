package com.security.test.service.serviceInterface;

public interface UserDetailService {
}
