package com.security.test.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ErrorPageController {
    @GetMapping("/access-denies-handler")
    public String accessDeniesHandler(){
        return "accessDenies/error-403";
    }
}
