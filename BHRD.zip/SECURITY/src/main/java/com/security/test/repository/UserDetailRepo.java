package com.security.test.repository;

import com.security.test.repository.model.Role;
import com.security.test.repository.model.User;
import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserDetailRepo {
    @Select("SELECT * FROM tbl_users where username = #{username}")
    @Results(value = {
            @Result(property = "id", column = "id"),
            @Result(property = "roles", column = "id", many = @Many(select = "findRolesByUserId"))
    })
    User loadUserByUsername(String username);

    @Select("SELECt * FROM tbl_roles r INNER JOIN tbl_user_roles ur")
    List<Role> findRolesByUserId(int id);
}
