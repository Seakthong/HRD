package com.security.test.service;

import com.security.test.service.serviceInterface.UserDetailService;
import org.springframework.stereotype.Service;

@Service
public class UserDetailServImp implements UserDetailService {

}
