package com.security.test.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MainController {

    @GetMapping("/")
    public String index(){
        return "zUser/index";
    }

    @GetMapping("/admin")
    public String admin(){
        return "admin/index";
    }

    @GetMapping("/editor")
    public String editor(){
        return "editor/index";
    }

    @GetMapping("/user")
    public String user(){
        return "user/index";
    }
}
