package com.security.test.configuration;

import com.security.test.service.serviceInterface.UserDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {
    @Autowired
    CustomAccessDeniesHandler customAccessDeniesHandler;

    @Autowired
    UserDetailService userDetailService;
    private AccessDeniedHandler accessDeniesHandler;

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.inMemoryAuthentication().withUser("admin").password("{noop}admin").roles("ADMIN");
        auth.inMemoryAuthentication().withUser("editor").password("{noop}editor").roles("EDITOR");
        auth.inMemoryAuthentication().withUser("user").password("{noop}user").roles("USER");

//        auth.jdbcAuthentication();
//        auth.userDetailsService(userDetailService);
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.formLogin();
        http.logout().logoutRequestMatcher(new AntPathRequestMatcher("/logout"));
        http.exceptionHandling().accessDeniedHandler(accessDeniesHandler);
        http.authorizeRequests().antMatchers("/admin/**").hasRole("ADMIN")
                .antMatchers("/editor/**").hasAnyRole("EDITOR","ADMIN")
                .antMatchers("/user/**").hasAnyRole("USER","EDITOR","ADMIN");
    }


}
