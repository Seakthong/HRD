package com.mvc.article.repository.articleProvider;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.jdbc.SQL;

public class ArticlesProvider {
//    public String find(){
////        String sql = "";
//        return new SQL(){{
//            SELECT("*");
//            FROM("tblarticles");
//        }}.toString();
//    }

//    public String find(Integer start, Integer limit){
////        String sql = "";
//        return new SQL(){{
//            SELECT("*");
//            FROM("tblarticles LIMIT #{limit}");
//        }}.toString();
//    }

    public String delete(@Param("id") Integer id){
        return new SQL(){{
            UPDATE("tblacticles");
            SET("status = 0");
            WHERE("id = #{id}");
        }}.toString();
    }

    public String viewAll(){
        return new SQL(){{
            SELECT("*");
            FROM("tblarticles AS a");
            INNER_JOIN("tblcategories AS c ON a.category_id = c.id");
            WHERE("status = 1");
        }}.toString();
    }

    public String viewOne(@Param("id") Integer id){
        return new SQL(){{
            SELECT("*");
            FROM("tblarticles AS a");
            INNER_JOIN("tblcategories AS c ON a.category_id = c.id");
            WHERE("status=1 AND id=#{id}");
        }}.toString();
    }
}


//Two parameter: @Param on provider and repo
//show use Wrapper class; (because null value);