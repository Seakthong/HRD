package com.mvc.article.service;

import com.mvc.article.repository.ArticleRepository;
import com.mvc.article.repository.model.Article;
import com.mvc.article.service.articleService.ArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class ArticleServiceImp implements ArticleService {

    @Autowired
    ArticleRepository articleRepository;

    @Override
    public List<Article> View() {
        return articleRepository.View();
    }

    @Override
    public void Insert(Article article) {
        articleRepository.Insert(article);
    }

    @Override
    public void Update(int id, Article article) {
        articleRepository.Update(id, article);
    }

    @Override
    public void Delete(int id) {
        articleRepository.Delete(id);
    }

    @Override
    public Article View(int id) {
        return articleRepository.View(id);
    }

    @Override
    public int Size() {
        return articleRepository.Size();
    }

    @Override
    public List<Article> Pagination(int limit, int page) {
        return articleRepository.View();
    }
}
