package com.mvc.article.controller;

import com.mvc.article.repository.model.Article;
import com.mvc.article.service.articleService.ArticleService;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.UUID;

@Controller
@RequestMapping("/article")
public class ArticleController {

    @Autowired
    ArticleService articleService;

    private static int curPage = 1;
    private static int curLimit = 5;
    private static int totalPage = 1;
    private static String curImage;

    @GetMapping( value = "/view")
    @ResponseBody
    public String show(ModelMap modelMap){
        System.out.println(articleService.View());
        String all = "";
        for(int i=0; i<articleService.View().size(); i++){
            all += articleService.View().get(i).toString();
        }
        return all;
//        int last = articleService.lastID();
//        if(last == 0) {
//            for (int i = last + 1; i < last + 10 + 1; i++) {
////                Article article = new Article(i, "TITLE", "AUTHOR", "DESCRIPTION", "/thumbnail/default.png");
////                articleService.Insert(article);
//            }
//        }

//        int size = 0;
//        modelMap.addAttribute("totalLimit", size);
//        size = articleService.listSize();
//        System.out.println(size);
//        if(size > 0) {
//            totalPage = (size % curLimit != 0 ? size / curLimit + 1 : size / curLimit);
//            modelMap.addAttribute("totalPage", totalPage);
//            modelMap.addAttribute("curLimit", curLimit);
//            modelMap.addAttribute("curPage", curPage);
//            modelMap.addAttribute("totalLimit", size);
//            modelMap.addAttribute("articles", articleService.ViewPagination(curLimit, curPage));
//        }
//        return "index";
    }

    @GetMapping(value = "/add")
    public String AddForm(ModelMap modelMap){
//        int id = articleService.lastID()+1;
//        modelMap.addAttribute("article",new Article(id));
//        modelMap.addAttribute("status",0);
        return ("form");
    }

    @PostMapping(value = "/add")
    @ResponseBody
//    public String Add(@ModelAttribute Article article,@RequestParam("file") MultipartFile file){
    public String Add(Article article){
        article = new Article("TITLE","Des","Author","Thumb",1,1);
        articleService.Insert(article);
//        article = getImageFile(0, file, article);
//        article.setId(articleService.lastID()+1);
//            articleService.Insert(article);
        return "redirect:/";
    }

    @GetMapping(value = "/init")
    public String init(@RequestParam int val){
//        int last = articleService.lastID();
//        for (int i=last + 1; i< last + val + 1; i++){
//            Article article = new Article(i,"why","why","why","/thumbnail/default.png");
//            articleService.Insert(article);
//        }
        return "redirect:/";
    }

    @GetMapping(value = "/articles")
    public String Delete(@RequestParam int id){
//        articleService.Delete(id);
        return "redirect:/";
    }

    @GetMapping(value = "/edit/{id}")
    public String Edit(@PathVariable int id, ModelMap modelMap){
//        modelMap.addAttribute("article",articleService.ViewOneRecord(id));
//        modelMap.addAttribute("old_thumbnail",articleService.ViewOneRecord(id).getThumbnail());
//        curImage = articleService.ViewOneRecord(id).getThumbnail();
//        modelMap.addAttribute("status",1);
        return "form";
    }
    @PostMapping(value = "/update")
    public String EditUpdate(@RequestParam int id, @ModelAttribute Article article,@RequestParam("file") MultipartFile file){
//        articleService.Update(id, getImageFile(1,file,article));
        return "redirect:/";
    }
    @GetMapping(value = "/view/{id}")
    public String View(@PathVariable int id, ModelMap modelMap){
//        modelMap.addAttribute("article",articleService.ViewOneRecord(id));
        return "view";
    }
    @GetMapping(value = "/pagination")
    public String Pagination(@RequestParam int page, ModelMap modelMap){
//        curPage = page;
        return "redirect:/";
    }
    @GetMapping(value = "/returnPage")
    public String returnPage(@RequestParam int limited){
//        curLimit = limited;
        return "redirect:/";
    }
    @GetMapping(value = "/curPage")
    public String curPagination(ModelMap modelMap){
//        modelMap.addAttribute("articles",articleService.ViewPagination(curLimit, curPage));
        return "index";
    }

    private static Article getImageFile(int type,MultipartFile file,Article article){
        String curPic = "/thumbnail/default.png";
        UUID uuid = UUID.randomUUID();
        String serverPath="src/main/resources/static/thumbnail/";
        if(type == 1){
            curPic = curImage;
        }

        if(file.isEmpty()){
            article.setThumbnail(curPic);
        }else{
            try {
                Files.copy(file.getInputStream(), Paths.get(serverPath,uuid+"-"+file.getOriginalFilename()));
                article.setThumbnail("resources/thumbnail/"+uuid+"-"+file.getOriginalFilename());
            }
            catch(IOException ioe){
            }
        }
        return article;
    }


}






















