package com.mvc.article.service.articleService;

import com.mvc.article.repository.model.Article;
import com.mvc.article.repository.model.Category;

import java.util.List;

public interface ArticleService {
    List<Article> View();
    void Insert(Article article);
    void Update(int id, Article article);
    void Delete(int id);
    Article View(int id);
    int Size();
    //    int lastID();
    List<Article> Pagination(int limit, int page);
}
