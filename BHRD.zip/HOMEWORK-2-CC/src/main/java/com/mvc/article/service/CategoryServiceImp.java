package com.mvc.article.service;

import com.mvc.article.repository.CategoryRepository;
import com.mvc.article.repository.model.Article;
import com.mvc.article.service.CategoryService.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryServiceImp implements CategoryService {
    @Autowired
    CategoryRepository categoryRepository;
    @Override
    public List<Article> View() {
        return categoryRepository.View();
    }

    @Override
    public boolean Insert(Article article) {
        return false;
    }

    @Override
    public boolean Update(int id, Article article) {
        return false;
    }

    @Override
    public boolean Delete(int id) {
        categoryRepository.Delete(id);
        return false;
    }

    @Override
    public Article View(int id) {
        return null;
    }

    @Override
    public int Size() {
        return 0;
    }

    @Override
    public List<Article> Pagination(int limit, int page) {
        return null;
    }
}
