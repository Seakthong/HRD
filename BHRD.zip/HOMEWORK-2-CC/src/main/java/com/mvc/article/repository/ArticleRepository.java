package com.mvc.article.repository;

import com.mvc.article.repository.articleProvider.ArticlesProvider;
import com.mvc.article.repository.model.Article;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import javax.websocket.server.ServerEndpoint;
import java.util.List;

@Repository
public interface ArticleRepository {
    @Insert("INSERT INTO tblarticles (title, author, description, thumbnail, status, category_id) VALUES(#{title},#{author},#{description},#{thumbnail},#{status},#{category_id})")
    void Insert(Article article);
    @Update("UPDATE tblarticles SET title=#{title}, author=#{author}, description=#{description}, thumbnail=#{thumbnail}, status=#{status}, category_id=#{category_id}  WHERE id = #{id}")
    void Update(@Param("id") int id,@Param("article") Article article);
//    @UpdateProvider(method = "delete", type = ArticlesProvider.class)
    void Delete(@Param("id") Integer id);
//    @SelectProvider(method = "viewAll", type = ArticlesProvider.class)
    List<Article> View();
//    @SelectProvider(method = "viewOne", type = ArticlesProvider.class)
    Article View(@Param("id") int id);
    int Size();
//    int lastID();
    List<Article> Pagination(int limit, int page);
}
