package com.mvc.article.repository;

import com.mvc.article.repository.model.Article;
import com.mvc.article.repository.model.Category;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CategoryRepository {
    boolean Insert(Article article);
    boolean Update(int id, Article article);
    boolean Delete(int id);
    List<Article> View();
    Article View(int id);
    int Size();
    //    int lastID();
    List<Article> Pagination(int limit, int page);
}
