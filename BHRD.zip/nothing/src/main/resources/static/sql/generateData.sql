INSERT INTO tblcategories (id, name) VALUES(1, "FIRST");
INSERT INTO tblcategories (id, name) VALUES(2, "SECOND");

