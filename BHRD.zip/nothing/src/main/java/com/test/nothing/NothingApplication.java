package com.test.nothing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NothingApplication {

    public static void main(String[] args) {
        SpringApplication.run(NothingApplication.class, args);
    }

}
