package com.hibernate.demo.configuration;

public class WebMvcConfiguration {
}
