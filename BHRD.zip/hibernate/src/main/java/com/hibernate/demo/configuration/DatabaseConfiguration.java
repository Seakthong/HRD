package com.hibernate.demo.configuration;

//@Configuration
public class DatabaseConfiguration {
//    @Bean
//    public DataSource dataSource(){
//        DriverManagerDataSource db = new DriverManagerDataSource();
//        db.setDriverClassName("org.postgresql.Driver");
//        db.setUrl("jdbc:postgresql:// localhost : 5432 / database-name");
//        db.setUsername("postgres");
//        db.setPassword("123");
//        return db;
//    }
}
